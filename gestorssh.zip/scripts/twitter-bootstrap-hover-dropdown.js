<!DOCTYPE html>
<html>
<head>
<style>
.g-recaptcha {
transform: scale(0.76);
transform-origin: 0 0
}

#g-recaptcha div {
transform:scale(0.891);
-webkit-transform:scale(0.891);
transform-origin:0 0;
-webkit-transform-origin:0 0;
}

</style>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Contas SSH Tunnel Premium Gratis, Contas SSH Tunnel Premium, Contas SSH Gratis, SSHTunnel, SSH Tunnel, OpenSSH, Proxy List, Squid, Dropbear, Fast Proxy, Best SSH Tunnel, Best Proxy, Best Squid, Proxy for SSH Tunnel, Proxy para SSH Tunnel, VPN, VPS, SSH, Proxy, Proxy Squid, Proxy Para HTTP Injector, Proxy Para eProxy, Proxy para KPN Tunnel, Internet Gratis, Internet Gratis Rapida, Free Internet, Fast Free Internet">
  <META name="keywords" content="Free Premium SSH Tunnel, Fast Free SSH Tunnel, SSH Tunnel Premium Gratis, Constas SSH, Fast SSH Tunnel, High Speed SSH Tunnel, High Speed Proxy Squid, Fast Proxy Squid, Melhores Proxys, Proxy Squid para SSH Tunnel, Free VPN, Fast VPN, Free Internet, Internet Gratis, Internet Gratis Rapida, HTTP Injector, Putty, SSH, eProxy, KPN Tunnel, Proxy Para HTTP Injector, Proxy para eProxy, Proxy para KPN Tunnel, Proxy list, Proxy para SSH Tunnel, VPN, SSH, Dropbear, Squid, Proxy, Tunnel, Free, Fast, Premium, Criar SSH Tunnel Premium Gratis, Criar SSH Tunnel, VPS, DigitalOcean, Vultr, Host1Plus">
  <title>SSH e VPN Para tunelamento - Pservers.com.br</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- main -->
  <link rel="stylesheet" href="main.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Animate -->
  <link rel="stylesheet" href="animate.min.css">
  <!-- abgs -->
  <link rel="stylesheet" href="abgs.css">
  <link rel="stylesheet" href="abgs-responsive.css">
  <link rel="stylesheet" href="abgs-customizado.css" type="text/css">
  <!-- Favicon -->
  <link rel="shortcut icon" href="../favicon.png" />
  <!-- css index -->
  <link rel="stylesheet" type="text/css" href="cssinicio.css" media="screen">
    <!-- css recaptcha
  <link rel="stylesheet" type="text/css" href="reccss.css">  -->
   <!-- Captcha -->
<script src="https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&render=explicit" async defer></script>
<script type="text/javascript">
  var CaptchaCallback = function() {
    $('.g-recaptcha').each(function(index, el) {
      grecaptcha.render(el, {'sitekey' : '6LfRiCEUAAAAAFeZKUn7VOocCdUbpkEezW7E3Q0K'});
    });
  };
</script>
<style>
@media screen and (max-height: 575px){
#rc-imageselect, .g-recaptcha {transform:scale(0.57);-webkit-transform:scale(0.47);transform-origin:0 0;-webkit-transform-origin:0 0;}
}
</style>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition login-page" style="padding-top: 130px;">

<header class="colored-top-bar">

			<div role="navigation" class="navbar navbar-default navbar-fixed-top space-top" style="top: 00px; height: 90px; line-height: 88px;">
				<div class="container">
					<div class="navbar-header">
						<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
							<span class="sr-only">Navegue</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand animate" data-animation-options="{&quot;animation&quot;:&quot;flipInY&quot;, &quot;duration&quot;:&quot;600&quot;}" href="/" style="font-size: 18px;">
							<img src="areainde.png" alt="GilNET TELECOM" title="GilNET TELECOM" class="animated lightSpeedIn" style="height: 75px; width: auto;">
						</a>
                        <i class="fa fa-refresh animate" style="margin-left: 75px; width: auto;"></i> <strong>Reset: 00:00:00 A.M (GMT -3)</strong>
					</div>
					<div class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
							<li><a href="?p=inicio" style="height: 90px; line-height: 88px;">Inicio</a></li>
								<li class="dropdown">
								<a class="dropdown-toggle" href="#" data-toggle="dropdown" data-hover="dropdown" style="height: 90px; line-height: 88px;">
									Criar SSH <b class="caret"></b>
								</a>
								<ul class="dropdown-menu">
									<li><a href="?p=sshfree">SSH 3-7 Dias</a></li>
									<li><a href="?p=sshpaga">SSH 30 Dias</a></li>
									<li><a href="?p=sshrevenda">Revenda SSH</a></li>
									<li><a href="?p=painel">SSH Painel</a></li>
									</ul>
							</li>
							<li><a href="planos.php" style="height: 90px; line-height: 88px;">Criar VPN <b class="caret"></b></a></li>
							<li class="dropdown">
								<a class="dropdown-toggle" href="#" data-toggle="dropdown" data-hover="dropdown" style="height: 90px; line-height: 88px;">
									Veja mais <i class="clip-arrow-down-3"></i>
								</a>
								<ul class="dropdown-menu">
									<li><a href="faq.php">F.A.Q.</a></li>
									<li><a href="cobertura.php">Cobertura</a></li>
									<li><a href="downloads.php">Downloads</a></li>
									<li><a href="noticias.php">Notícias</a></li>
									<li><a href="tecnologia.php">Tecnologia</a></li>
									<li><a href="suporte.php">Suporte técnico</a></li>
									</ul>
							</li>
							<li><a href="fale.php" style="height: 90px; line-height: 88px;">Contato</a></li>
							<li>
								<a type="button" data-toggle="modal" data-target="#central" href="putamae" class="waves-effect waves-light" style="height: 90px; line-height: 88px;">
									<i class="fa fa-user"></i> Central do assinante
								</a>
							</li>


						</ul>
					</div>
				</div>
			</div>
		</header>
<!--
<div class="js">
            <div id="preloader"></div>
        </div>
-->
<!-- Pre Carregamento -->





<div align="center" class="rainbow8">
<div class="rainbowtext"><h2 id="h2up" style="color:#FFFFFF;">Premium Contas VPN &amp; SSH Gratis</h2><span style="font-size:x-large;" class="rainbowtext">Protegido &amp; Seguro Sua Privacidade | Alta Performance &amp; Uptime</span><center>
</center></div>
</div>
<!-- Div dos anuncios -->
<div id="anuncio1">
<div class="corpoanuncio">
         <p class="publichi"><strong>Publicidade</strong></p>

         <div class="codigoanunc" style="text-align: center;">
            <!-- Pservers1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9134582023142119"
     data-ad-slot="5561613186"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

               </div>
      </div>
</div>
<!-- Fim Div dos anuncios -->
<!-- Fim menu -->
  <!-- Paginas -->
   <?php
	if(isset($_GET["p"])){
					$page = $_GET["p"];
					if($page and file_exists("".$page.".php")) {
					include("".$page.".php");
					} else {
					include("inicial2.php");
				  }
				}else{
					include("inicial2.php");
				}

	?>
 <!-- Fim Paginas -->



<script>
// mostra datatime correndo
window.onload = function(){
    setInterval(function(){
        // Obtém a data/hora atual
var data = new Date();

// Guarda cada pedaço em uma variável
var dia     = data.getDate();           // 1-31
var dia_sem = data.getDay();            // 0-6 (zero=domingo)
var mes     = data.getMonth();          // 0-11 (zero=janeiro)
var ano2    = data.getYear();           // 2 dígitos
var ano4    = data.getFullYear();       // 4 dígitos

momentoAtual = data;
   	hora = momentoAtual.getHours()
   	minuto = momentoAtual.getMinutes()
   	segundo = momentoAtual.getSeconds()

   	str_segundo = new String (segundo)
   	if (str_segundo.length == 1)
      	segundo = "0" + segundo

   	str_minuto = new String (minuto)
   	if (str_minuto.length == 1)
      	minuto = "0" + minuto

   	str_hora = new String (hora)
   	if (str_hora.length == 1)
      	hora = "0" + hora

        var str_data = dia + '/' + (mes+1) + '/' + ano4;
        horaImprimible = hora + " : " + minuto + " : " + segundo

        document.getElementById('time').innerHTML = "<small>Hoje é " + str_data + " às " + horaImprimible+" </small>";
    }, 1000);
};
</script>

<div id="anuncio2" align="center">
<div class="corpoanuncio">
         <p class="publichi"><strong>Publicidade</strong></p>

         <div class="codigoanunc" style="text-align: center;">
           <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- pservers2 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-9134582023142119"
     data-ad-slot="9852211982"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

               </div>
      </div>
</div>

<div class="container">
<p class="text-muted pull-left">© 2016-2017 Pservers.com.br. All Right Reserved.</p>
<p class="text-muted pull-right"> <eae id="time"></eae> | <a href="?p=termos">Termos e Condições</a> | <a href="?p=privacy">Politica de Privacidade</a> | <a href="?p=assinar">Contato</a></p>
</div>


<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-100932556-1', 'auto');
  ga('send', 'pageview');

</script>
<script src="http://gilnet.com.br/midias_GILNET04/plugins/jquery.transit/jquery.transit.js"></script>
<script src="twitter-bootstrap-hover-dropdown.js"></script>

<!--
<script>
jQuery(document).ready(function($) {

// site preloader -- also uncomment the div in the header and the css style for #preloader
$(window).load(function(){
	$('#preloader').fadeOut(100,function(){$(this).remove();});
});

});
</script>

-->
<?php require_once("adblock.php"); ?>
</body>
</html>
